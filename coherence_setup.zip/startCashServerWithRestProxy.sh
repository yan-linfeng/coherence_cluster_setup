#/bin/bash
if [ -z $1 ]; then
    echo "Plase pass COHERENCE_HOME as argument" 
    exit 1
fi

# Configure CLASSPATH
COHERENCE_HOME=${1}
DEPENDENCIES=$(pwd)/dependencies/
CLASSPATH=$(pwd)/cswrp:$(pwd)/config
CLASSPATH=$CLASSPATH:$COHERENCE_HOME/lib/coherence.jar:$COHERENCE_HOME/lib/coherence-rest.jar
for file in $DEPENDENCIES*
do 
    export CLASSPATH=$CLASSPATH:$file
done

# Calculate the half of physical memory
if [ "$(uname)" == "Darwin" ]; then 
    # macOS
    mem_total=$(sysctl hw.memsize | awk '{print $2}')
    mem_total=$(($mem_total / 1024 / 1024))
elif [ "$(uname)" == "Linux" ]; then
    # Linux
    mem_total=$(free -m | grep Mem | awk '{print $2}')
fi
mem_half=$(($mem_total / 2))

# Start Coherence Cache Server with Rest Proxy enabled
java -server -XX:+UseG1GC -XX:+DisableExplicitGC -Xms${mem_half}m -Xmx${mem_half}m -cp  $CLASSPATH -Dcoherence.poc.rest.enabled=true -Djava.net.preferIPv4Stack=true com.tangosol.net.DefaultCacheServer